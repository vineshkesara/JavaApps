package com.info.custInfo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {

	
    @GetMapping("/register")
    public String greetingForm(Model model) {
    	System.out.println("get mapping>>>");
        model.addAttribute("register", new Register());
        return "register";
    }

    @PostMapping("/register")
    public String greetingSubmit(@ModelAttribute Register greeting) {
    	System.out.println("post mapping >>");
        return "result";
    }

}
